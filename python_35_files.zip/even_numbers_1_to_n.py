n = int(input("Enter N: "))

for i in range(2, n + 1, 2):
    print(i)
