# Python Programs 39–65

This folder contains Python solutions for problems 39 through 65.

## Notes
- Each problem is in a separate `.py` file.
- Run any file with Python 3:
  `python filename.py`
- Problem 42 uses these assumed scholarship rules: marks >= 75%, attendance >= 75%, and annual family income <= 300000.
- Problem 40 asks for the minimum balance as an input.
