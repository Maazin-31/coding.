amount = float(input("Enter withdrawal amount: "))
balance = float(input("Enter account balance: "))
min_balance = float(input("Enter minimum balance: "))

if amount <= 0:
    print("Rejected: Invalid withdrawal amount")
elif amount > balance:
    print("Rejected: Insufficient balance")
elif balance - amount < min_balance:
    print("Rejected: Minimum balance rule violated")
else:
    balance -= amount
    print("Withdrawal approved")
    print("Remaining balance:", balance)
