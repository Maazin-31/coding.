x = float(input("Enter x: "))
n = int(input("Enter n: "))

if n < 0:
    result = 1
    base = x
    exponent = -n
    while exponent > 0:
        if exponent % 2 == 1:
            result *= base
        base *= base
        exponent //= 2
    result = 1 / result
else:
    result = 1
    base = x
    exponent = n
    while exponent > 0:
        if exponent % 2 == 1:
            result *= base
        base *= base
        exponent //= 2

print("x^n:", result)
