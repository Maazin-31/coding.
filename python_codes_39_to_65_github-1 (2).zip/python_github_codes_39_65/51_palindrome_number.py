n = int(input("Enter a number: "))
original = n
n = abs(n)
reverse = 0

while n > 0:
    reverse = reverse * 10 + n % 10
    n //= 10

if abs(original) == reverse:
    print("Palindrome")
else:
    print("Not a palindrome")
