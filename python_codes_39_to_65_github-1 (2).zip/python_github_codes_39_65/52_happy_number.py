def sum_of_square_digits(n):
    total = 0
    while n > 0:
        digit = n % 10
        total += digit * digit
        n //= 10
    return total

n = int(input("Enter a number: "))
seen = set()

while n != 1 and n not in seen:
    seen.add(n)
    n = sum_of_square_digits(n)

if n == 1:
    print("Happy number")
else:
    print("Not a happy number")
