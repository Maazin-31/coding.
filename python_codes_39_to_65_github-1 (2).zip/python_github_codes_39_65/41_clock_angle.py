hour = int(input("Enter hour (1-12): "))
minute = int(input("Enter minutes (0-59): "))

hour_angle = (hour % 12) * 30 + minute * 0.5
minute_angle = minute * 6
difference = abs(hour_angle - minute_angle)
angle = min(difference, 360 - difference)

print("Smaller angle:", angle, "degrees")
