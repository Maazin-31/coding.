a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

x, y = abs(a), abs(b)
while y != 0:
    x, y = y, x % y

gcd = x
lcm = 0 if a == 0 or b == 0 else abs(a * b) // gcd

print("LCM:", lcm)
