n = abs(int(input("Enter a number: ")))

digits = str(n)
for digit in digits:
    print(digit, end=" ")
